var searchData=
[
  ['koin',['Koin',['../classKoin.html',1,'Koin'],['../classKoin.html#a68434ca0d1c219f1863e9d43bc9a0be4',1,'Koin::Koin()']]]
];
