var searchData=
[
  ['makanan',['Makanan',['../classMakanan.html',1,'']]]
];
