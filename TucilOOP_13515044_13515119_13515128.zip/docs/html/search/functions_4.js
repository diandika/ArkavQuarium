var searchData=
[
  ['getcoin',['getCoin',['../classSiput.html#a4f5cceefab1fdfb494c7eebaabcd0300',1,'Siput']]],
  ['getentity',['getEntity',['../classAquarium.html#acbf7e576e86b0bb641ff93d479936a04',1,'Aquarium']]],
  ['getindex',['getIndex',['../classLinkedList.html#a79cd18cb0fbb69f54665125542340ca9',1,'LinkedList']]],
  ['getkind',['getKind',['../classEntity.html#adef8f8f46bf832bf07fe5b91cc808e3b',1,'Entity']]],
  ['getlevel',['getLevel',['../classGuppy.html#a60e492213ba14f89484b9f26c0a6a414',1,'Guppy']]],
  ['getx',['getX',['../classEntity.html#a8bad399d8b9c6bf23ecbb8f0b4fe6a64',1,'Entity']]],
  ['gety',['getY',['../classEntity.html#a4f2a264033195f9004a494069c5865f0',1,'Entity']]],
  ['guppy',['Guppy',['../classGuppy.html#a28662f8f82c743d7c01deac586e6ca5e',1,'Guppy']]]
];
