var searchData=
[
  ['setentity',['setEntity',['../classAquarium.html#ae48965035f8aa2ad3cbb54f6cbf9f34e',1,'Aquarium']]],
  ['setkenyang',['setKenyang',['../classGuppy.html#ac8ff64e3a7e8ea83284971ef698d8823',1,'Guppy']]],
  ['setkind',['setKind',['../classEntity.html#aa9cdd93807cbc1b39e7afc95110deb60',1,'Entity']]],
  ['setlevel',['setLevel',['../classGuppy.html#aa9a5c199be094098529c973ba403087e',1,'Guppy']]],
  ['setx',['setX',['../classEntity.html#a3fbf5396e39940e060e48e1c298992dc',1,'Entity']]],
  ['sety',['setY',['../classEntity.html#a2241bb3600829d1c3f28577fecf739af',1,'Entity']]],
  ['siput',['Siput',['../classSiput.html',1,'Siput'],['../classSiput.html#abbbf9701e21784f1e08d3c3aa92c0105',1,'Siput::Siput()']]]
];
