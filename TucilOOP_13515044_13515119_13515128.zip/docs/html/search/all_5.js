var searchData=
[
  ['isempty',['isEmpty',['../classLinkedList.html#a7ecbb28e82117a680839ed0dc28ebdce',1,'LinkedList']]],
  ['iskenyang',['isKenyang',['../classGuppy.html#a7567664b093759516cd155a1764847e6',1,'Guppy']]],
  ['islapar',['isLapar',['../classGuppy.html#a49961b1bcd93d43496f081d1732ddce8',1,'Guppy']]]
];
