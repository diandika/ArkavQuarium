var searchData=
[
  ['dropcoin',['dropCoin',['../classGuppy.html#ad67e3b60be4e541b15e90b9e6581a920',1,'Guppy::dropCoin()'],['../classPiranha.html#aee107987f36631002f04c5283564382b',1,'Piranha::dropCoin()']]]
];
