var searchData=
[
  ['makanan',['Makanan',['../classMakanan.html#aa3e4801d7e413401c502e1b6fa4e994a',1,'Makanan']]],
  ['move',['move',['../classEntity.html#a624e85b5e363a70b0a7b2e04912c6cdf',1,'Entity::move()'],['../classGuppy.html#ae6002948d74b3741bed34a7311be4377',1,'Guppy::move()'],['../classKoin.html#a086d48dfd240ab4a139e0c97e8b7fb04',1,'Koin::move()'],['../classMakanan.html#a02f224d8090f673bb67a2191d3b992ae',1,'Makanan::move()'],['../classSiput.html#a40de61cd661fe26389b4f53e071e44d4',1,'Siput::move()']]]
];
